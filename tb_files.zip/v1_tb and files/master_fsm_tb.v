`timescale 1ns / 1ps
// ============================================================
//  Testbench : master_fsm
//  Opcodes: 0=IDLE, 1=RESET_X, 2=RESET_Y, 3=UPDT_X,
//           4=UPDT_Y, 5=EXE
//  Flow: RETRIEVE reads ctrl, dispatches to sub-state,
//        sub-state returns to RETRIEVE when done
// ============================================================
module master_fsm_tb;

reg        clk, rst_n, exe_done, empty_from_fifo;
reg        done_load_x, done_load_y;
reg  [3:0] ctrl;
wire       mux_ctrl, load_x, load_w, next, exe_ready;
wire       reset_w_mem, reset_d_mem;
wire       pntr_incr_x, pntr_incr_d;
wire       updt_x, updt_y;

master_fsm uut (
    .ctrl(ctrl),.clk(clk),.rst_n(rst_n),.exe_done(exe_done),
    .empty_from_fifo(empty_from_fifo),
    .done_load_x(done_load_x),.done_load_y(done_load_y),
    .mux_ctrl(mux_ctrl),.load_x(load_x),.load_w(load_w),
    .next(next),.exe_ready(exe_ready),
    .reset_w_mem(reset_w_mem),.reset_d_mem(reset_d_mem),
    .pntr_incr_x(pntr_incr_x),.pntr_incr_d(pntr_incr_d),
    .updt_x(updt_x),.updt_y(updt_y)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;

task cycle; begin @(posedge clk); #1; end endtask

task check_sig;
    input exp_next, exp_exe_ready, exp_mux; input integer id;
    begin
        if(next===exp_next && exe_ready===exp_exe_ready && mux_ctrl===exp_mux) begin
            $display("[PASS] T%0d next=%b exe_ready=%b mux=%b",id,next,exe_ready,mux_ctrl);
            pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d next=%b exe_ready=%b mux=%b exp=%b/%b/%b",
                     id,next,exe_ready,mux_ctrl,exp_next,exp_exe_ready,exp_mux);
            fail_cnt=fail_cnt+1;
        end
    end
endtask

initial begin
    $dumpfile("master_fsm_tb.vcd"); $dumpvars(0,master_fsm_tb);
    ctrl=0; exe_done=0; empty_from_fifo=0; done_load_x=0; done_load_y=0;
    rst_n=0; cycle; cycle; rst_n=1; cycle;

    // T1 – comes up in RETRIEVE (IDLE->RETRIEVE), ctrl=0 -> goes IDLE
    cycle; // RETRIEVE
    check_sig(1,0,0,1); // next=1 in RETRIEVE

    // After RETRIEVE with ctrl=0 -> IDLE, then back to RETRIEVE
    ctrl=0; cycle; cycle;
    check_sig(0,0,0,2); // IDLE outputs

    // T3 – RESET_X: ctrl=1
    @(negedge clk); ctrl=4'b0001; cycle; // RETRIEVE sees ctrl=1
    cycle; // -> RESET_X; reset_x_fsm will fire done in 1 cycle
    // RESET_X state: exe_reset_x=1 -> reset_x_fsm fires done immediately
    cycle; cycle;
    // Should return to RETRIEVE: next=1
    check_sig(1,0,0,3);

    // T4 – RESET_Y: ctrl=2, mux_ctrl=1 while in RESET_Y
    @(negedge clk); ctrl=4'b0010; cycle; cycle; cycle;
    // In RESET_Y: mux_ctrl=1
    if(mux_ctrl===1) begin $display("[PASS] T4 mux_ctrl=1 in RESET_Y"); pass_cnt=pass_cnt+1; end
    else             begin $display("[FAIL] T4 mux_ctrl=%b (exp 1)",mux_ctrl); fail_cnt=fail_cnt+1; end
    cycle; cycle;

    // T5 – UPDT_X: ctrl=3 (PRE_UPDT_X -> UPDT_X)
    // updt_x=1 in PRE_UPDT_X
    @(negedge clk); ctrl=4'b0011; cycle; // RETRIEVE
    cycle; // PRE_UPDT_X: updt_x=1
    if(updt_x===1) begin $display("[PASS] T5 updt_x=1 in PRE_UPDT_X"); pass_cnt=pass_cnt+1; end
    else           begin $display("[FAIL] T5 updt_x=%b (exp 1)",updt_x); fail_cnt=fail_cnt+1; end

    // Let updt_x_fsm run: it needs empty=0 then counter reaches 8, then done_load_x=1
    empty_from_fifo=0;
    repeat(10) cycle;
    done_load_x=1; cycle; cycle;
    done_load_x=0;
    // Should be back in RETRIEVE
    check_sig(1,0,0,5);

    // T6 – EXE: ctrl=5
    @(negedge clk); ctrl=4'b0101; cycle; cycle;
    // EXE state: exe_ready=1
    check_sig(0,1,0,6);
    // Simulate exe_done
    @(negedge clk); exe_done=1; cycle;
    exe_done=0;
    cycle; // RETRIEVE
    check_sig(1,0,0,7);

    // T7 – UPDT_Y: ctrl=4
    @(negedge clk); ctrl=4'b0100; cycle;
    cycle; // PRE_UPDT_Y: updt_y=1
    if(updt_y===1) begin $display("[PASS] T7 updt_y=1 in PRE_UPDT_Y"); pass_cnt=pass_cnt+1; end
    else           begin $display("[FAIL] T7 updt_y=%b (exp 1)",updt_y); fail_cnt=fail_cnt+1; end

    // T8 – rst_n clears
    @(negedge clk); rst_n=0; cycle;
    check_sig(0,0,0,8);
    rst_n=1;

    $display("\n=== MASTER_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #20000 begin $display("[TIMEOUT]"); $finish; end
endmodule
