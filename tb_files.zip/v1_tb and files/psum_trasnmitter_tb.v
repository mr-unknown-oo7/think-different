`timescale 1ns / 1ps
// ============================================================
//  Testbench : psum_trasnmitter
//  States: IDLE -> TRANS_1 -> TRANS_2 -> TRANS_3 -> IDLE
//  Transmits op_val_1, op_val_2, op_val_3 in sequence to output FIFO
//  Back-pressure via full signal
// ============================================================
module psum_trasnmitter_tb;

reg         clk, rst_n, exe, ready, full;
reg  [15:0] op_val_1, op_val_2, op_val_3;
wire [15:0] op_data_bus;
wire        done, valid;

psum_trasnmitter uut (
    .op_val_1(op_val_1),.op_val_2(op_val_2),.op_val_3(op_val_3),
    .clk(clk),.rst_n(rst_n),.exe(exe),.ready(ready),.full(full),
    .op_data_bus(op_data_bus),.done(done),.valid(valid)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;

task check_bus;
    input [15:0] exp_bus; input exp_valid, exp_done; input integer id;
    begin
        if(op_data_bus===exp_bus && valid===exp_valid && done===exp_done) begin
            $display("[PASS] T%0d bus=%0d valid=%b done=%b",id,op_data_bus,valid,done);
            pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d bus=%0d valid=%b done=%b exp=%0d/%b/%b",
                     id,op_data_bus,valid,done,exp_bus,exp_valid,exp_done);
            fail_cnt=fail_cnt+1;
        end
    end
endtask

task cycle; begin @(posedge clk); #1; end endtask

initial begin
    $dumpfile("psum_trasnmitter_tb.vcd"); $dumpvars(0,psum_trasnmitter_tb);
    {exe,ready,full} = 0;
    op_val_1=16'd100; op_val_2=16'd200; op_val_3=16'd300;
    rst_n=0; cycle; cycle; rst_n=1; cycle;

    // T1 – IDLE: bus=0, valid=0, done=0
    check_bus(0,0,0,1);

    // T2 – exe=1: IDLE -> TRANS_1, full=0 -> bus=op_val_1, valid=1
    @(negedge clk); exe=1; full=0; cycle;
    @(negedge clk); exe=0; cycle;
    check_bus(100,1,0,2);

    // T3 – TRANS_1 -> TRANS_2: bus=op_val_2
    cycle;
    check_bus(200,1,0,3);

    // T4 – TRANS_2 -> TRANS_3: bus=op_val_3, done=1
    cycle;
    check_bus(300,1,1,4);

    // T5 – TRANS_3 -> IDLE (full=0)
    cycle;
    check_bus(0,0,0,5);

    // T6 – back-pressure: full=1 during TRANS_1: hold state
    op_val_1=16'd10; op_val_2=16'd20; op_val_3=16'd30;
    @(negedge clk); exe=1; full=1; cycle;
    @(negedge clk); exe=0; cycle;
    // full=1 -> bus=0, valid=0
    check_bus(0,0,0,6);

    // T7 – release full: TRANS_1 proceeds
    @(negedge clk); full=0; cycle;
    check_bus(10,1,0,7);

    // T8 – full=1 mid-TRANS_2: hold
    @(negedge clk); full=1; cycle;
    check_bus(0,0,0,8);

    // T9 – release, TRANS_2->TRANS_3
    @(negedge clk); full=0; cycle;
    check_bus(20,1,0,9);

    cycle;
    check_bus(30,1,1,10);

    // T11 – reset clears state
    @(negedge clk); exe=1; full=0; cycle;
    @(negedge clk); rst_n=0; cycle;
    check_bus(0,0,0,11);
    rst_n=1; exe=0;

    $display("\n=== PSUM_TRANSMITTER: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
