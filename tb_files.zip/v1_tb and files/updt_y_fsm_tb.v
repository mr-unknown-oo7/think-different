`timescale 1ns / 1ps
// ============================================================
//  Testbench : updt_y_fsm
//  Like updt_x_fsm but counter limit is y_dim_ip (configurable)
//  done fires when counter==y_dim_ip AND done_load_y==1
// ============================================================
module updt_y_fsm_tb;

reg        clk, rst_n, exe, empty, done_load_y;
reg  [3:0] y_dim_ip;
wire       done, ptr_incr, load_y;

updt_y_fsm uut (
    .clk(clk),.rst_n(rst_n),.exe(exe),.empty(empty),
    .done_load_y(done_load_y),.y_dim_ip(y_dim_ip),
    .done(done),.ptr_incr(ptr_incr),.load_y(load_y)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task check_out;
    input exp_pi, exp_ly, exp_done; input integer id;
    begin
        if(ptr_incr===exp_pi && load_y===exp_ly && done===exp_done) begin
            $display("[PASS] T%0d ptr_incr=%b load_y=%b done=%b",id,ptr_incr,load_y,done);
            pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d ptr_incr=%b load_y=%b done=%b exp=%b/%b/%b",
                     id,ptr_incr,load_y,done,exp_pi,exp_ly,exp_done);
            fail_cnt=fail_cnt+1;
        end
    end
endtask

initial begin
    $dumpfile("updt_y_fsm_tb.vcd"); $dumpvars(0,updt_y_fsm_tb);
    rst_n=0; exe=0; empty=1; done_load_y=0; y_dim_ip=4;
    @(posedge clk); #1; @(posedge clk); #1; rst_n=1; @(posedge clk); #1;

    // T1 – IDLE
    check_out(0,0,0,1);

    // T2 – exe=1, empty=1: waits in START_EXE
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check_out(0,0,0,2);

    // T3 – empty=0: MID_EXE starts, ptr_incr=1
    @(negedge clk); empty=0; exe=0; @(posedge clk); #1;
    check_out(1,0,0,3);

    // T4 – run y_dim_ip-2 more cycles to reach counter=y_dim_ip (4)
    for(k=0;k<3;k=k+1) begin @(posedge clk); #1; end
    // counter=4=y_dim_ip -> BUFF: load_y=1
    @(posedge clk); #1;
    check_out(0,1,0,4);

    // T5 – assert done_load_y
    @(negedge clk); done_load_y=1; @(posedge clk); #1;
    check_out(0,1,1,5);

    // T6 – back to IDLE
    @(posedge clk); #1; @(posedge clk); #1;
    check_out(0,0,0,6);
    done_load_y=0;

    // T7 – y_dim=8 test: should run 8 pointer increments
    y_dim_ip=8; empty=1;
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    @(negedge clk); empty=0; exe=0; @(posedge clk); #1;
    check_out(1,0,0,7);
    for(k=0;k<7;k=k+1) begin @(posedge clk); #1; end
    // counter=8=y_dim -> BUFF
    @(posedge clk); #1;
    check_out(0,1,0,71);
    @(negedge clk); done_load_y=1; @(posedge clk); #1;
    check_out(0,1,1,72);
    @(posedge clk); #1; done_load_y=0;

    // T8 – rst_n clears mid-run
    @(negedge clk); exe=1; empty=0; @(posedge clk); #1; @(posedge clk); #1;
    @(negedge clk); rst_n=0; @(posedge clk); #1;
    check_out(0,0,0,8);
    rst_n=1; exe=0; empty=1;

    $display("\n=== UPDT_Y_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
