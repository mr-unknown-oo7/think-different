`timescale 1ns / 1ps
// ============================================================
//  Testbench : reset_y_fsm  (structurally identical to reset_x_fsm)
//  States: IDLE -> EXE (reset+done=1) -> IDLE
// ============================================================
module reset_y_fsm_tb;

reg  clk, rst_n, exe;
wire reset, done;

reset_y_fsm uut (.clk(clk),.rst_n(rst_n),.exe(exe),.reset(reset),.done(done));

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;

task check2;
    input r,d; input integer id;
    begin
        if(reset===r && done===d) begin
            $display("[PASS] T%0d reset=%b done=%b",id,reset,done); pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d reset=%b done=%b exp=%b/%b",id,reset,done,r,d); fail_cnt=fail_cnt+1;
        end
    end
endtask

initial begin
    $dumpfile("reset_y_fsm_tb.vcd"); $dumpvars(0,reset_y_fsm_tb);
    rst_n=0; exe=0;
    @(posedge clk); #1; @(posedge clk); #1; rst_n=1; @(posedge clk); #1;

    // T1 – IDLE: both outputs 0
    check2(0,0,1);

    // T2 – exe=1: enters EXE -> reset=1, done=1
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check2(1,1,2);

    // T3 – returns to IDLE after done_temp
    @(negedge clk); exe=0; @(posedge clk); #1;
    check2(0,0,3);

    // T4 – pulse exe again
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check2(1,1,4);

    // T5 – rst_n=0 forces IDLE
    @(negedge clk); rst_n=0; @(posedge clk); #1;
    check2(0,0,5);
    @(negedge clk); rst_n=1; exe=0;

    // T6 – stable IDLE after release
    @(posedge clk); #1;
    check2(0,0,6);

    $display("\n=== RESET_Y_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #5000 begin $display("[TIMEOUT]"); $finish; end
endmodule
