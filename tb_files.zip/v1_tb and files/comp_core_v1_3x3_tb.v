`timescale 1ns / 1ps
// ============================================================
//  Testbench : comp_core_v1_3x3
//  Integration-level test of the compute core.
//  Drives ctrl opcodes, feeds data, and checks output.
//  NOTE: top_mod's async_fifo is NOT included here;
//        data is driven directly into the core.
// ============================================================
module comp_core_v1_3x3_tb;

reg        clk, rst_n;
reg        valid_from_fifo, ip_fifo_empty;
reg  [7:0] data;
reg  [3:0] ctrl;
reg  [3:0] y_dim;
wire       valid_to_fifo, op_fifo_full;
wire [15:0] op_data_bus;
wire        r_en_ins, r_en;

comp_core_v1_3x3 uut (
    .clk(clk),.rst_n(rst_n),
    .valid_from_fifo(valid_from_fifo),
    .ip_fifo_empty(ip_fifo_empty),
    .data(data),.ctrl(ctrl),.y_dim(y_dim),
    .valid_to_fifo(valid_to_fifo),
    .op_fifo_full(op_fifo_full),
    .op_data_bus(op_data_bus),
    .r_en_ins(r_en_ins),
    .r_en(r_en)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task cycle; begin @(posedge clk); #1; end endtask

task send_byte; input [7:0] d;
    begin
        @(negedge clk); valid_from_fifo=1; ip_fifo_empty=0; data=d;
        @(posedge clk); #1;
    end
endtask

task set_ctrl; input [3:0] c;
    begin @(negedge clk); ctrl=c; @(posedge clk); #1; end
endtask

initial begin
    $dumpfile("comp_core_tb.vcd"); $dumpvars(0,comp_core_v1_3x3_tb);
    {valid_from_fifo,ip_fifo_empty,data,ctrl,y_dim} = 0;
    rst_n=0; repeat(3) cycle; rst_n=1; cycle;

    // ---- PHASE 1: RESET_X (ctrl=1) ----
    $display("\n-- Phase 1: RESET_X --");
    set_ctrl(4'b0001); repeat(5) cycle;

    // ---- PHASE 2: RESET_Y (ctrl=2) ----
    $display("\n-- Phase 2: RESET_Y --");
    set_ctrl(4'b0010); repeat(5) cycle;

    // ---- PHASE 3: UPDT_X – load weight memory (ctrl=3) ----
    // Feed 9 weight bytes: kernel = [[1,2,3],[4,5,6],[7,8,9]]
    $display("\n-- Phase 3: UPDT_X (load weights) --");
    set_ctrl(4'b0011);
    for(k=1;k<=9;k=k+1) send_byte(k);
    @(negedge clk); valid_from_fifo=0; ip_fifo_empty=1; repeat(5) cycle;

    // ---- PHASE 4: UPDT_Y – load data memory (ctrl=4, y_dim=4) ----
    // Image row layout (4 cols, 5 rows): row_i = [i+1, i+2, i+3, i+4]
    $display("\n-- Phase 4: UPDT_Y (load data) --");
    y_dim=4;
    set_ctrl(4'b0100);
    for(k=1;k<=20;k=k+1) send_byte(k);
    @(negedge clk); valid_from_fifo=0; ip_fifo_empty=1; repeat(5) cycle;

    // ---- PHASE 5: EXE (ctrl=5) ----
    $display("\n-- Phase 5: EXE --");
    set_ctrl(4'b0101);
    op_fifo_full = 0; // no back-pressure
    // Wait for valid_to_fifo outputs (up to 50 cycles)
    begin : wait_valid
        integer timeout;
        for(timeout=0; timeout<100; timeout=timeout+1) begin
            cycle;
            if(valid_to_fifo) begin
                $display("[INFO] Output: op_data_bus=%0d (valid_to_fifo=1)", op_data_bus);
            end
        end
    end

    // ---- PHASE 6: Reset mid-execution ----
    $display("\n-- Phase 6: rst_n assertion --");
    @(negedge clk); rst_n=0; cycle; cycle;
    if(r_en_ins===0 && r_en===0)
        $display("[PASS] T_RST: outputs cleared after reset");
    else
        $display("[NOTE] T_RST: some signals may retain state, check waveform");
    rst_n=1;

    $display("\n=== COMP_CORE: Simulation complete. Check waveform for full verification. ===\n");
    $finish;
end
initial #50000 begin $display("[TIMEOUT]"); $finish; end
endmodule
