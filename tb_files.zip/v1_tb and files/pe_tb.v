`timescale 1ns / 1ps
// ============================================================
//  Testbench : pe (Processing Element)
//  Tests: reset, B-shift pipeline, MAC correctness,
//         exe=0 hold, overflow documentation
// ============================================================
module pe_tb;

reg        clk, rst_n, exe, shift_val_x;
reg  [7:0] a_ip, b_ip;
wire [15:0] result;

pe uut (.clk(clk),.rst_n(rst_n),.exe(exe),
        .shift_val_x(shift_val_x),.a_ip(a_ip),.b_ip(b_ip),.result(result));

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt = 0, fail_cnt = 0;

task tick;
    input sv; input ex; input [7:0] bv;
    begin @(negedge clk); shift_val_x=sv; exe=ex; b_ip=bv; @(posedge clk); #1; end
endtask

task check;
    input [15:0] exp; input integer id;
    begin
        if(result===exp) begin $display("[PASS] T%0d result=%0d",id,result); pass_cnt=pass_cnt+1; end
        else             begin $display("[FAIL] T%0d result=%0d exp=%0d",id,result,exp); fail_cnt=fail_cnt+1; end
    end
endtask

initial begin
    $dumpfile("pe_tb.vcd"); $dumpvars(0,pe_tb);
    rst_n=1; exe=0; shift_val_x=0; a_ip=0; b_ip=0;

    // T1 – reset clears result
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1; rst_n=1; @(posedge clk); #1;
    check(0,1);

    // T2 – shift B={3,2,1}, A still 0 => result=0
    tick(1,0,1); tick(1,0,2); tick(1,0,3); tick(0,1,0); check(0,2);

    // T3 – A={1,1,1}, B={3,2,1} => 6
    force uut.A[0]=8'd1; force uut.A[1]=8'd1; force uut.A[2]=8'd1;
    tick(0,0,0); tick(0,1,0); check(6,3);
    release uut.A[0]; release uut.A[1]; release uut.A[2];

    // T4 – A={2,3,4}, B={3,2,1} => 2*3+3*2+4*1=16
    force uut.A[0]=8'd2; force uut.A[1]=8'd3; force uut.A[2]=8'd4;
    tick(0,1,0); check(16,4);
    release uut.A[0]; release uut.A[1]; release uut.A[2];

    // T5 – exe=0 holds result
    force uut.A[0]=8'd10; force uut.A[1]=8'd20; force uut.A[2]=8'd30;
    tick(0,0,0); check(16,5); // still 16
    release uut.A[0]; release uut.A[1]; release uut.A[2];

    // T6 – overflow: A=B={255,255,255} => 195075 wraps to 63
    tick(1,0,255); tick(1,0,255); tick(1,0,255);
    force uut.A[0]=8'd255; force uut.A[1]=8'd255; force uut.A[2]=8'd255;
    tick(0,1,0); check(63,6);
    $display("       (195075 mod 65536 = 63, overflow documented)");
    release uut.A[0]; release uut.A[1]; release uut.A[2];

    // T7 – sliding window B: shift+exe simultaneously
    @(negedge clk); rst_n=0; @(posedge clk); #1; rst_n=1;
    force uut.A[0]=8'd1; force uut.A[1]=8'd1; force uut.A[2]=8'd1;
    tick(1,0,10); tick(1,0,20); tick(1,1,30); check(60,7);
    tick(1,1,40); check(90,8);
    release uut.A[0]; release uut.A[1]; release uut.A[2];

    // T9 – zero inputs
    @(negedge clk); rst_n=0; @(posedge clk); #1; rst_n=1;
    tick(1,0,0); tick(1,0,0); tick(1,0,0); tick(0,1,0); check(0,9);

    $display("\n=== PE: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
