`timescale 1ns / 1ps
// ============================================================
//  Testbench : d_mem_3x3 (data/activation memory, 5×16 max)
//  Tests: reset, write pixels, 5-channel output with y_dim stride,
//         ptr_incr, reset pointer behaviour
// ============================================================
module d_mem_3x3_tb;

reg        clk, valid, rst_n, reset, updt, ptr_incr;
reg  [3:0] y_dim_ip;
reg  [7:0] data;
wire [7:0] ch1,ch2,ch3,ch4,ch5;

d_mem_3x3 uut (
    .clk(clk),.valid(valid),.rst_n(rst_n),.reset(reset),
    .updt(updt),.ptr_incr(ptr_incr),.y_dim_ip(y_dim_ip),
    .data(data),
    .output_data_ch_1(ch1),.output_data_ch_2(ch2),.output_data_ch_3(ch3),
    .output_data_ch_4(ch4),.output_data_ch_5(ch5)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task check5;
    input [7:0] e1,e2,e3,e4,e5; input integer id;
    begin
        if(ch1===e1&&ch2===e2&&ch3===e3&&ch4===e4&&ch5===e5) begin
            $display("[PASS] T%0d ch={%0d,%0d,%0d,%0d,%0d}",id,ch1,ch2,ch3,ch4,ch5); pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d ch={%0d,%0d,%0d,%0d,%0d} exp={%0d,%0d,%0d,%0d,%0d}",
                     id,ch1,ch2,ch3,ch4,ch5,e1,e2,e3,e4,e5); fail_cnt=fail_cnt+1;
        end
    end
endtask

task write_byte; input [7:0] d;
    begin @(negedge clk); valid=1; data=d; @(posedge clk); #1; end
endtask

initial begin
    $dumpfile("d_mem_3x3_tb.vcd"); $dumpvars(0,d_mem_3x3_tb);
    {valid,rst_n,reset,updt,ptr_incr} = 0; y_dim_ip=0; data=0;

    // T1 – reset: all outputs 0
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1;
    check5(0,0,0,0,0,1);
    rst_n=1; @(posedge clk); #1;

    // T2 – write 5 rows × 4 cols (y_dim=4) image data
    // Pixel layout: row0={1,2,3,4}, row1={5,6,7,8}, ..., row4={17,18,19,20}
    // Output pointers at reset with y_dim=4: ptr[i]=i*4 -> {0,4,8,12,16}
    // ch1=mem[0]=1, ch2=mem[4]=5, ch3=mem[8]=9, ch4=mem[12]=13, ch5=mem[16]=17
    y_dim_ip=4;
    @(negedge clk); updt=1; @(posedge clk); #1;
    @(negedge clk); updt=0; @(posedge clk); #1;
    // reset pointers with y_dim=4
    @(negedge clk); reset=1; @(posedge clk); #1;
    @(negedge clk); reset=0; @(posedge clk); #1;
    for(k=1;k<=20;k=k+1) write_byte(k);
    @(negedge clk); valid=0; @(posedge clk); #2;
    check5(1,5,9,13,17,2);

    // T3 – ptr_incr: all pointers +1 -> ch={2,6,10,14,18}
    @(negedge clk); ptr_incr=1; @(posedge clk); #1;
    @(negedge clk); ptr_incr=0; @(posedge clk); #2;
    check5(2,6,10,14,18,3);

    // T4 – ptr_incr again -> ch={3,7,11,15,19}
    @(negedge clk); ptr_incr=1; @(posedge clk); #1;
    @(negedge clk); ptr_incr=0; @(posedge clk); #2;
    check5(3,7,11,15,19,4);

    // T5 – reset restores pointers -> ch={1,5,9,13,17}
    @(negedge clk); reset=1; @(posedge clk); #1;
    @(negedge clk); reset=0; @(posedge clk); #2;
    check5(1,5,9,13,17,5);

    // T6 – y_dim=8 stride test (5 rows × 8 cols)
    y_dim_ip=8;
    @(negedge clk); updt=1; @(posedge clk); #1;
    @(negedge clk); updt=0; @(posedge clk); #1;
    @(negedge clk); reset=1; @(posedge clk); #1;
    @(negedge clk); reset=0; @(posedge clk); #1;
    for(k=1;k<=40;k=k+1) write_byte(k);
    @(negedge clk); valid=0; @(posedge clk); #2;
    // ptr[i]=i*8 -> {0,8,16,24,32} -> ch={1,9,17,25,33}
    check5(1,9,17,25,33,6);

    // T7 – global rst_n clears memory
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1;
    check5(0,0,0,0,0,7);
    rst_n=1;

    $display("\n=== D_MEM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #20000 begin $display("[TIMEOUT]"); $finish; end
endmodule
