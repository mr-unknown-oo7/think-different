`timescale 1ns / 1ps
// ============================================================
//  Testbench : pe_array (3×3 systolic PE array)
//  Tests: reset, single MAC cycle, summed partial products,
//         shift_x pipeline, exe=0 hold
// ============================================================
module pe_array_tb;

reg        clk, rst_n, exe, shift_x;
reg  [7:0] w1,w2,w3, x1,x2,x3,x4,x5;
wire [15:0] op1,op2,op3;

pe_array uut (
    .exe(exe),.clk(clk),.shift_x(shift_x),.rst_n(rst_n),
    .w_bus_1(w1),.w_bus_2(w2),.w_bus_3(w3),
    .x_bus_1(x1),.x_bus_2(x2),.x_bus_3(x3),.x_bus_4(x4),.x_bus_5(x5),
    .op_val_1(op1),.op_val_2(op2),.op_val_3(op3)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;

task check3;
    input [15:0] e1,e2,e3; input integer id;
    begin
        if(op1===e1 && op2===e2 && op3===e3) begin
            $display("[PASS] T%0d op={%0d,%0d,%0d}",id,op1,op2,op3); pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d op={%0d,%0d,%0d} exp={%0d,%0d,%0d}",id,op1,op2,op3,e1,e2,e3); fail_cnt=fail_cnt+1;
        end
    end
endtask

task cycle; begin @(posedge clk); #1; end endtask

initial begin
    $dumpfile("pe_array_tb.vcd"); $dumpvars(0,pe_array_tb);
    {exe,shift_x,w1,w2,w3,x1,x2,x3,x4,x5} = 0; rst_n=0;
    cycle; cycle; rst_n=1;

    // T1 – reset: all sums zero
    check3(0,0,0,1);

    // T2 – Load B registers: shift x values {1,2,3,4,5} through 3 cycles
    // PE(row i, col j) gets x_bus[i+j]
    // After 3 shifts with same x inputs, each PE's B = {xval, xval, xval}
    // Use all-1 weights and x={1,2,3,4,5}
    // Force A registers directly for determinism
    // W row 0=1, row 1=2, row 2=3; x values stay constant during shifts
    w1=1; w2=2; w3=3;
    x1=1; x2=2; x3=3; x4=4; x5=5;
    // Shift x into B for 3 cycles
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    // Force A weights for all 9 PEs (row i uses w_bus[i], A=w_bus[i])
    // PE[i][j] -> result[i+3*j]
    // Row 0 (A=1): PE[0][0]->B={x1,x1,x1}=1, PE[0][1]->B={x2,x2,x2}=2, PE[0][2]->B={x3,x3,x3}=3
    // Wait – A is never loaded from a_ip in the pe; force directly
    force uut.row[0].col[0].u_pe.A[0]=1; force uut.row[0].col[0].u_pe.A[1]=1; force uut.row[0].col[0].u_pe.A[2]=1;
    force uut.row[0].col[1].u_pe.A[0]=1; force uut.row[0].col[1].u_pe.A[1]=1; force uut.row[0].col[1].u_pe.A[2]=1;
    force uut.row[0].col[2].u_pe.A[0]=1; force uut.row[0].col[2].u_pe.A[1]=1; force uut.row[0].col[2].u_pe.A[2]=1;
    force uut.row[1].col[0].u_pe.A[0]=2; force uut.row[1].col[0].u_pe.A[1]=2; force uut.row[1].col[0].u_pe.A[2]=2;
    force uut.row[1].col[1].u_pe.A[0]=2; force uut.row[1].col[1].u_pe.A[1]=2; force uut.row[1].col[1].u_pe.A[2]=2;
    force uut.row[1].col[2].u_pe.A[0]=2; force uut.row[1].col[2].u_pe.A[1]=2; force uut.row[1].col[2].u_pe.A[2]=2;
    force uut.row[2].col[0].u_pe.A[0]=3; force uut.row[2].col[0].u_pe.A[1]=3; force uut.row[2].col[0].u_pe.A[2]=3;
    force uut.row[2].col[1].u_pe.A[0]=3; force uut.row[2].col[1].u_pe.A[1]=3; force uut.row[2].col[1].u_pe.A[2]=3;
    force uut.row[2].col[2].u_pe.A[0]=3; force uut.row[2].col[2].u_pe.A[1]=3; force uut.row[2].col[2].u_pe.A[2]=3;
    // Execute: each PE result[i][j] = A*(B[0]+B[1]+B[2]) but MAC is A[0]*B[0]+A[1]*B[1]+A[2]*B[2]
    // Since A all same=w, B all same after 3 shifts with fixed x:
    // PE(0,0): B={1,1,1},A={1,1,1} -> 1+1+1=3
    // PE(0,1): B={2,2,2},A={1,1,1} -> 6
    // PE(0,2): B={3,3,3},A={1,1,1} -> 9
    // sum[0] = result[0]+result[1]+result[2] = 3+6+9 = 18
    // PE(1,0): B={2,2,2},A={2,2,2} -> 12; PE(1,1):B={3,3,3},A={2,2,2}->18; PE(1,2):B={4,4,4},A={2,2,2}->24
    // sum[1] = 12+18+24 = 54
    // PE(2,0): B={3,3,3},A={3,3,3}->27; PE(2,1):B={3,3,3} (x_bus[3]=x_bus3=x3=3 note bug in array),A={3,3,3}->27
    // pe_array assigns x_bus[3]=x_bus_3 (typo – uses x3 not x4), x_bus[4]=x_bus_4
    // PE(2,2): x_bus[2+2]=x_bus[4]=x_bus_4=4 -> B={4,4,4},A={3,3,3}->36
    // sum[2] = 27+27+36 = 90
    @(negedge clk); shift_x=0; exe=1; @(posedge clk); #1;
    @(posedge clk); #1; // extra cycle for sum register
    check3(18,54,90,2);
    // Release all forces
    release uut.row[0].col[0].u_pe.A[0]; release uut.row[0].col[0].u_pe.A[1]; release uut.row[0].col[0].u_pe.A[2];
    release uut.row[0].col[1].u_pe.A[0]; release uut.row[0].col[1].u_pe.A[1]; release uut.row[0].col[1].u_pe.A[2];
    release uut.row[0].col[2].u_pe.A[0]; release uut.row[0].col[2].u_pe.A[1]; release uut.row[0].col[2].u_pe.A[2];
    release uut.row[1].col[0].u_pe.A[0]; release uut.row[1].col[0].u_pe.A[1]; release uut.row[1].col[0].u_pe.A[2];
    release uut.row[1].col[1].u_pe.A[0]; release uut.row[1].col[1].u_pe.A[1]; release uut.row[1].col[1].u_pe.A[2];
    release uut.row[1].col[2].u_pe.A[0]; release uut.row[1].col[2].u_pe.A[1]; release uut.row[1].col[2].u_pe.A[2];
    release uut.row[2].col[0].u_pe.A[0]; release uut.row[2].col[0].u_pe.A[1]; release uut.row[2].col[0].u_pe.A[2];
    release uut.row[2].col[1].u_pe.A[0]; release uut.row[2].col[1].u_pe.A[1]; release uut.row[2].col[1].u_pe.A[2];
    release uut.row[2].col[2].u_pe.A[0]; release uut.row[2].col[2].u_pe.A[1]; release uut.row[2].col[2].u_pe.A[2];

    // T3 – exe=0 holds sums
    @(negedge clk); exe=0; shift_x=0; @(posedge clk); #1; @(posedge clk); #1;
    check3(18,54,90,3);

    // T4 – reset clears sums
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1;
    check3(0,0,0,4);
    rst_n=1;

    // T5 – all-zero weights => sums stay 0 regardless of x
    x1=10; x2=20; x3=30; x4=40; x5=50;
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    @(negedge clk); shift_x=1; exe=0; @(posedge clk); #1;
    @(negedge clk); shift_x=0; exe=1; @(posedge clk); #1;
    @(posedge clk); #1;
    check3(0,0,0,5);

    $display("\n=== PE_ARRAY: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #20000 begin $display("[TIMEOUT]"); $finish; end
endmodule
