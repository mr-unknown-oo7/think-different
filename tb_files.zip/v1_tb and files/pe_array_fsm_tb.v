`timescale 1ns / 1ps
// ============================================================
//  Testbench : pe_array_fsm
//  States: IDLE -> LOAD_X/LOAD_W -> SHIFT_X -> EXE_P_ARRAY
//       -> EXE_PSUM_TRANS -> IDLE (or SHIFT_X for next column)
// ============================================================
module pe_array_fsm_tb;

reg        clk, rst_n, exe, load_x, load_w, p_sum_trans_done;
reg  [3:0] y_dim;
wire       shift_x, exe_p_array, exe_psum_trans;
wire       done_load_x, done_load_w;

pe_array_fsm uut (
    .clk(clk),.rst_n(rst_n),.exe(exe),.load_x(load_x),.load_w(load_w),
    .p_sum_trans_done(p_sum_trans_done),.y_dim(y_dim),
    .shift_x(shift_x),.exe_p_array(exe_p_array),.exe_psum_trans(exe_psum_trans),
    .done_load_x(done_load_x),.done_load_w(done_load_w)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task check_state;
    input e_sx, e_ep, e_ept; input integer id;
    begin
        if(shift_x===e_sx && exe_p_array===e_ep && exe_psum_trans===e_ept) begin
            $display("[PASS] T%0d sx=%b ep=%b ept=%b",id,shift_x,exe_p_array,exe_psum_trans);
            pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d sx=%b ep=%b ept=%b exp=%b/%b/%b",
                     id,shift_x,exe_p_array,exe_psum_trans,e_sx,e_ep,e_ept);
            fail_cnt=fail_cnt+1;
        end
    end
endtask

task cycle; begin @(posedge clk); #1; end endtask

initial begin
    $dumpfile("pe_array_fsm_tb.vcd"); $dumpvars(0,pe_array_fsm_tb);
    {exe,load_x,load_w,p_sum_trans_done} = 0; y_dim=4;
    rst_n=0; cycle; cycle; rst_n=1; cycle;

    // T1 – IDLE: shift_x=1, exe_p_array=0, exe_psum_trans=0
    check_state(1,0,0,1);

    // T2 – load_x=1: enters LOAD_X, counter increments
    @(negedge clk); load_x=1; cycle; cycle;
    check_state(1,0,0,2); // still shifting (loading)
    @(negedge clk); load_x=0;

    // T3 – Run 2 more cycles for counter to reach 3 (done_load_x fires at counter==3)
    cycle; cycle; cycle;
    // done_load_x should fire, FSM -> IDLE
    check_state(1,0,0,3);

    // T4 – load_w=1: enters LOAD_W
    @(negedge clk); load_w=1; cycle; cycle;
    check_state(1,0,0,4);
    @(negedge clk); load_w=0;
    cycle; cycle; cycle;
    check_state(1,0,0,41);

    // T5 – exe=1: IDLE->EXE_P_ARRAY->EXE_PSUM_TRANS
    @(negedge clk); exe=1; cycle;
    @(negedge clk); exe=0; cycle;
    // EXE_P_ARRAY: shift_x=0, exe_p_array=1
    check_state(0,1,0,5);

    // T6 – next cycle: EXE_PSUM_TRANS
    cycle;
    check_state(0,0,1,6);

    // T7 – p_sum_trans_done=0 -> goes to SHIFT_X
    @(negedge clk); p_sum_trans_done=0; cycle;
    // SHIFT_X: shift_x=1
    check_state(1,0,0,7);

    // T8 – SHIFT_X auto-transitions to EXE_P_ARRAY
    cycle;
    check_state(0,1,0,8);

    // T9 – EXE_P_ARRAY -> EXE_PSUM_TRANS, this time p_sum_trans_done=1 -> IDLE
    cycle;
    @(negedge clk); p_sum_trans_done=1; cycle;
    check_state(1,0,0,9); // back to IDLE
    p_sum_trans_done=0;

    // T10 – reset during exe
    @(negedge clk); exe=1; cycle;
    @(negedge clk); rst_n=0; cycle;
    check_state(1,0,0,10);
    rst_n=1; exe=0;

    $display("\n=== PE_ARRAY_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
