`timescale 1ns / 1ps
// ============================================================
//  Testbench : w_mem_3x3 (3×3 weight memory)
//  Tests: reset, write 9 weights, pointer output,
//         ptr_incr advances column pointers, updt resets ptrs
// ============================================================
module w_mem_3x3_tb;

reg       clk, valid, rst_n, reset, updt, ptr_incr;
reg [7:0] data;
wire [7:0] ch1, ch2, ch3;

w_mem_3x3 uut (
    .clk(clk),.valid(valid),.rst_n(rst_n),.reset(reset),
    .updt(updt),.ptr_incr(ptr_incr),.data(data),
    .output_data_ch_1(ch1),.output_data_ch_2(ch2),.output_data_ch_3(ch3)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task check3;
    input [7:0] e1,e2,e3; input integer id;
    begin
        if(ch1===e1 && ch2===e2 && ch3===e3) begin
            $display("[PASS] T%0d ch={%0d,%0d,%0d}",id,ch1,ch2,ch3); pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d ch={%0d,%0d,%0d} exp={%0d,%0d,%0d}",id,ch1,ch2,ch3,e1,e2,e3); fail_cnt=fail_cnt+1;
        end
    end
endtask

task write_byte; input [7:0] d;
    begin @(negedge clk); valid=1; data=d; @(posedge clk); #1; end
endtask

initial begin
    $dumpfile("w_mem_3x3_tb.vcd"); $dumpvars(0,w_mem_3x3_tb);
    {valid,rst_n,reset,updt,ptr_incr,data} = 0;

    // T1 – global reset: outputs should be 0 (all mem=0)
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1;
    check3(0,0,0,1);
    rst_n=1; @(posedge clk); #1;

    // T2 – assert updt to reset pointers and mem_cntr
    @(negedge clk); updt=1; @(posedge clk); #1;
    @(negedge clk); updt=0; valid=0; @(posedge clk); #1;

    // T3 – write 9 weights: 10,11,12,20,21,22,30,31,32
    // After write: mem[0..8] = {10,11,12,20,21,22,30,31,32}
    // Initial output_ptr[0]=0, [1]=3, [2]=6 (SKIP_VAL=3)
    // ch1=mem[0]=10, ch2=mem[3]=20, ch3=mem[6]=30
    for(k=0;k<3;k=k+1) write_byte(10+k);
    for(k=0;k<3;k=k+1) write_byte(20+k);
    for(k=0;k<3;k=k+1) write_byte(30+k);
    @(negedge clk); valid=0; @(posedge clk); #2;
    check3(10,20,30,3);

    // T4 – ptr_incr: pointers advance by 1 -> ch={11,21,31}
    @(negedge clk); ptr_incr=1; @(posedge clk); #1;
    @(negedge clk); ptr_incr=0; @(posedge clk); #2;
    check3(11,21,31,4);

    // T5 – ptr_incr again: ch={12,22,32}
    @(negedge clk); ptr_incr=1; @(posedge clk); #1;
    @(negedge clk); ptr_incr=0; @(posedge clk); #2;
    check3(12,22,32,5);

    // T6 – reset signal resets pointers back to {0,3,6} -> ch={10,20,30}
    @(negedge clk); reset=1; @(posedge clk); #1;
    @(negedge clk); reset=0; @(posedge clk); #2;
    check3(10,20,30,6);

    // T7 – updt resets mem_cntr; write new weights 1..9
    @(negedge clk); updt=1; @(posedge clk); #1;
    @(negedge clk); updt=0; @(posedge clk); #1;
    for(k=1;k<=9;k=k+1) write_byte(k);
    @(negedge clk); valid=0; @(posedge clk); #2;
    // mem[0..8]={1..9}, ptr={0,3,6} -> ch={1,4,7}
    check3(1,4,7,7);

    // T8 – rst_n clears all memory
    @(negedge clk); rst_n=0; @(posedge clk); #1; @(posedge clk); #1;
    check3(0,0,0,8);
    rst_n=1;

    $display("\n=== W_MEM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
