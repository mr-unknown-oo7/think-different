`timescale 1ns / 1ps
// ============================================================
//  Testbench : updt_x_fsm
//  State machine that loads the data memory (X / activation)
//  States: IDLE -> START_EXE -> MID_EXE -> BUFF -> DONE -> IDLE
//  done fires when counter==8 AND done_load_x==1
// ============================================================
module updt_x_fsm_tb;

reg  clk, rst_n, exe, empty, done_load_x;
wire done, ptr_incr, load_x;

updt_x_fsm uut (
    .clk(clk),.rst_n(rst_n),.exe(exe),.empty(empty),
    .done_load_x(done_load_x),.done(done),.ptr_incr(ptr_incr),.load_x(load_x)
);

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;
integer k;

task check_out;
    input exp_pi, exp_lx, exp_done; input integer id;
    begin
        if(ptr_incr===exp_pi && load_x===exp_lx && done===exp_done) begin
            $display("[PASS] T%0d ptr_incr=%b load_x=%b done=%b",id,ptr_incr,load_x,done);
            pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d ptr_incr=%b load_x=%b done=%b exp=%b/%b/%b",
                     id,ptr_incr,load_x,done,exp_pi,exp_lx,exp_done);
            fail_cnt=fail_cnt+1;
        end
    end
endtask

initial begin
    $dumpfile("updt_x_fsm_tb.vcd"); $dumpvars(0,updt_x_fsm_tb);
    rst_n=0; exe=0; empty=1; done_load_x=0;
    @(posedge clk); #1; @(posedge clk); #1; rst_n=1; @(posedge clk); #1;

    // T1 – IDLE: all outputs 0
    check_out(0,0,0,1);

    // T2 – exe=1, empty=1: stays START_EXE (waiting for data)
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check_out(0,0,0,2);

    // T3 – empty=0: starts counting ptr_incr, entering MID_EXE
    @(negedge clk); empty=0; exe=0; @(posedge clk); #1;
    check_out(1,0,0,3); // ptr_incr begins

    // T4 – run 7 more cycles to reach counter=8
    for(k=0;k<7;k=k+1) begin @(posedge clk); #1; end
    // counter should now be at 8, entering BUFF
    @(posedge clk); #1;
    // In BUFF: load_x=1
    check_out(0,1,0,4);

    // T5 – assert done_load_x to complete
    @(negedge clk); done_load_x=1; @(posedge clk); #1;
    // done fires
    check_out(0,1,1,5);

    // T6 – transitions to DONE -> IDLE
    @(posedge clk); #1; @(posedge clk); #1;
    check_out(0,0,0,6);
    done_load_x=0;

    // T7 – rst_n mid-operation
    @(negedge clk); exe=1; empty=0; @(posedge clk); #1; @(posedge clk); #1;
    @(negedge clk); rst_n=0; @(posedge clk); #1;
    check_out(0,0,0,7);
    rst_n=1; exe=0; empty=1;

    $display("\n=== UPDT_X_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #10000 begin $display("[TIMEOUT]"); $finish; end
endmodule
