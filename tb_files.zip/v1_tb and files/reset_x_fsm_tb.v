`timescale 1ns / 1ps
// ============================================================
//  Testbench : reset_x_fsm
//  States: IDLE -> EXE (assert reset+done for 1 cycle) -> IDLE
// ============================================================
module reset_x_fsm_tb;

reg  clk, rst_n, exe;
wire reset, done;

reset_x_fsm uut (.clk(clk),.rst_n(rst_n),.exe(exe),.reset(reset),.done(done));

initial clk = 0;
always #5 clk = ~clk;

integer pass_cnt=0, fail_cnt=0;

task check2;
    input r, d; input integer id;
    begin
        if(reset===r && done===d) begin
            $display("[PASS] T%0d reset=%b done=%b",id,reset,done); pass_cnt=pass_cnt+1;
        end else begin
            $display("[FAIL] T%0d reset=%b done=%b exp=%b/%b",id,reset,done,r,d); fail_cnt=fail_cnt+1;
        end
    end
endtask

initial begin
    $dumpfile("reset_x_fsm_tb.vcd"); $dumpvars(0,reset_x_fsm_tb);
    rst_n=0; exe=0;
    @(posedge clk); #1; @(posedge clk); #1; rst_n=1;

    // T1 – idle: reset=0, done=0
    @(posedge clk); #1;
    check2(0,0,1);

    // T2 – assert exe: should enter EXE, reset=1, done=1
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check2(1,1,2);

    // T3 – hold exe high: stays in EXE (done_temp=1 -> back to IDLE next cycle)
    // Note: done_temp=1 in EXE means next_state=IDLE
    @(posedge clk); #1;
    // EXE->IDLE transition (done_temp drives it back)
    // After IDLE: reset=0, done=0
    @(negedge clk); exe=0; @(posedge clk); #1;
    check2(0,0,3);

    // T4 – de-assert exe in IDLE, nothing changes
    @(posedge clk); #1;
    check2(0,0,4);

    // T5 – re-trigger exe
    @(negedge clk); exe=1; @(posedge clk); #1; @(posedge clk); #1;
    check2(1,1,5);
    @(negedge clk); exe=0; @(posedge clk); #1;

    // T6 – global reset mid-operation
    @(negedge clk); exe=1; @(posedge clk); #1;
    @(negedge clk); rst_n=0; @(posedge clk); #1;
    check2(0,0,6);
    rst_n=1;

    $display("\n=== RESET_X_FSM: %0d PASS | %0d FAIL ===\n", pass_cnt, fail_cnt);
    $finish;
end
initial #5000 begin $display("[TIMEOUT]"); $finish; end
endmodule
